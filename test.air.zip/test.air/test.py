# -*- encoding=utf8 -*-
__author__ = "wbl19"

from airtest.core.api import *

auto_setup(__file__)

touch(Template(r"tpl1560084053518.png", record_pos=(0.0, 0.613), resolution=(1080, 1920)))
touch(Template(r"tpl1560084885187.png", record_pos=(-0.263, 0.084), resolution=(1080, 1920)))
text("new_cashbook",enter=False)

touch(Template(r"tpl1560085169423.png", record_pos=(0.21, 0.217), resolution=(1080, 1920)))

touch(Template(r"tpl1560085235713.png", record_pos=(-0.273, -0.427), resolution=(1080, 1920)))
touch(Template(r"tpl1560085246490.png", record_pos=(-0.252, -0.22), resolution=(1080, 1920)))
text("1")
touch(Template(r"tpl1560085278670.png", record_pos=(-0.391, 0.563), resolution=(1080, 1920)))
text("1")
swipe(Template(r"tpl1560085312870.png", record_pos=(-0.344, 0.391), resolution=(1080, 1920)), vector=[-0.0221, -0.431])
swipe(Template(r"tpl1560085332046.png", record_pos=(-0.308, 0.558), resolution=(1080, 1920)), vector=[0.0075, -0.5149])
touch(Template(r"tpl1560085344024.png", record_pos=(-0.01, 0.652), resolution=(1080, 1920)))

keyevent("BACK")

swipe(Template(r"tpl1560085441064.png", record_pos=(-0.009, 0.775), resolution=(1080, 1920)), vector=[-0.0061, -0.4231])

touch(Template(r"tpl1560085448868.png", record_pos=(0.004, 0.802), resolution=(1080, 1920)))
touch(Template(r"tpl1560085465934.png", record_pos=(-0.001, 0.729), resolution=(1080, 1920)))
touch(Template(r"tpl1560085473274.png", record_pos=(-0.265, 0.087), resolution=(1080, 1920)))
text("送女友的礼物")
touch(Template(r"tpl1560085492518.png", record_pos=(0.212, 0.215), resolution=(1080, 1920)))
swipe(Template(r"tpl1560085520394.png", record_pos=(-0.324, 0.164), resolution=(1080, 1920)), vector=[-0.1595, 0.0027])
touch(Template(r"tpl1560085527354.png", record_pos=(0.349, 0.164), resolution=(1080, 1920)))
keyevent("BACK")
